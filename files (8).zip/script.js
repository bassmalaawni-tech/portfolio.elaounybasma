/* ===== CONFIGURATION : modifiez ici vos liens ===== */
const CONFIG = {
  linkedin: "https://www.linkedin.com/in/basma-el-aouny-", // URL reprise de votre CV
  cv: "assets/CV-Basma-EL-AOUNY.pdf",                        // ← déposez votre PDF dans assets/
  email: "bassmalaawni@gmail.com"
};

/* Applique la configuration aux liens */
document.querySelectorAll("#linkedin-link,#linkedin-btn").forEach(a => a.href = CONFIG.linkedin);
document.getElementById("cv-btn").href = CONFIG.cv;
document.getElementById("year").textContent = new Date().getFullYear();

/* Menu mobile */
const btn = document.querySelector(".menu-btn"), nav = document.getElementById("nav");
const setMenu = open => {
  nav.classList.toggle("open", open);
  btn.setAttribute("aria-expanded", open);
  btn.setAttribute("aria-label", open ? "Fermer le menu" : "Ouvrir le menu");
};
btn.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
nav.addEventListener("click", e => { if (e.target.tagName === "A") setMenu(false); });
document.addEventListener("keydown", e => { if (e.key === "Escape") setMenu(false); });

/* Cartes de projets : afficher / masquer les détails */
document.querySelectorAll(".more").forEach(b => {
  b.addEventListener("click", () => {
    const panel = document.getElementById(b.getAttribute("aria-controls"));
    const open = b.getAttribute("aria-expanded") === "true";
    b.setAttribute("aria-expanded", !open);
    panel.hidden = open;
    b.textContent = open ? "Voir les détails" : "Masquer les détails";
  });
});

/* Logos : remplace le monogramme si assets/logos/<nom>.svg existe */
document.querySelectorAll(".tools li[data-logo]").forEach(li => {
  const img = new Image();
  img.alt = "";
  img.onload = () => li.querySelector(".mono").replaceWith(img);
  img.src = `assets/logos/${li.dataset.logo}.svg`;
});

/* Formulaire : prépare un e-mail (aucun envoi depuis le site) */
const form = document.getElementById("contact-form"), status = document.getElementById("form-status");
form.addEventListener("submit", e => {
  e.preventDefault();
  if (!form.checkValidity()) { status.textContent = "Veuillez remplir tous les champs avec une adresse e-mail valide."; form.reportValidity(); return; }
  const d = new FormData(form);
  const body = `${d.get("message")}\n\n— ${d.get("nom")} (${d.get("email")})`;
  location.href = `mailto:${CONFIG.email}?subject=${encodeURIComponent(d.get("objet"))}&body=${encodeURIComponent(body)}`;
  status.textContent = "Votre application e-mail s'ouvre avec le message prérempli. Envoyez-le depuis celle-ci.";
});
